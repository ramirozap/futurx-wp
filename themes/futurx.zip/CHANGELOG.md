# barebones changelog
## 3.0
* Refreshed simplified tooling, new feaatures and improvements 
