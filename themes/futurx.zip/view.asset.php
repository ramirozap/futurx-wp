<?php return array('dependencies' => array(), 'version' => '3f6b9529bab3ec83d960');
